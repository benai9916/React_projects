import { FC } from 'react';

import HomePage from 'pages/HomePage';

 const App: FC = () => {
  return (
    <>
      <HomePage />
    </>
  );
}

export default App;
